if (typeof(Storage) == "undefined") {
    location.replace("/frontend/authenticate.html");
}
