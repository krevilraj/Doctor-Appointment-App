Amrit Shrestha

Name: Amrit Shrestha

CollegeID: Your college ID

Batch: Jan19D


# Frontend code architecture

Provide a brief description of your front end code architecture including folder structure, API consumption, etc.

